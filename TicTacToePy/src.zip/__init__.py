from game import game
import os

path = os.path.realpath(__file__)
os.name == 'nt' and os.chdir(path[:path.index('\\__init__.py')])
os.name == 'posix' and os.chdir(path[:path.index('/__init__.py')])

input()