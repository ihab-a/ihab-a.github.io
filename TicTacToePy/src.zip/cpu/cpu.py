from dataio import io
from random import randrange
from game import game
def evaluate(board, first, reverse=False):
	if (board == '.........') :
		return randrange(0, 9)
	return io.findNextOptimalPos(board, first, reverse)
