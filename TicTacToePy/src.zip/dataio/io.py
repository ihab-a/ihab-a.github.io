import json

# 0 : cpu / 1 : player
def findNextOptimalPos(board, first, reverse=False):
	tmp = ''
	for i in board:
		if(i=='0'):tmp+='1'
		elif(i=='1'):tmp+='0'
		else:tmp+='.'
	if(reverse):board=tmp
	if(not(first)):
		data = json.load(open("Vdata/data2.json", "r"))
		return data[board]
	data = json.load(open("Vdata/data1.json", "r"))
	return data[board]

