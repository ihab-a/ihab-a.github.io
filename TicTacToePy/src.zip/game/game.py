from random import random
from ui import screen
from tkinter import messagebox
from re import match
from cpu import cpu
from settings import loader

def reset():
	global board, role, PLAYER, CPU_FIRST, PLAYER_SYMBOL
	PLAYER = 1
	screen.screen.clear()
	screen.createSlots()
	board = [i for i in '.........']
	role = int(int(random()*10) % 2 == 0)
	if(int(loader.SETTINGS['CPU_VS_CPU'])) : role = 0
	while(1):
		try :
			# PLAYER_SYMBOL = int(screen._input("choose 1 or 2", "play with 1 (Triangle) or 2 (X)?")) - 1
			PLAYER_SYMBOL = 0
			if(PLAYER != 0 and PLAYER != 1) : raise Exception
			break
		except : None
	if(role != PLAYER):
		CPU_FIRST = True
		chk_cpu()
	else:
		CPU_FIRST = False
	return

def chk_cpu():
	global role, PLAYER, board, CPU_FIRST
	if(role != PLAYER):
		cpu_des = cpu.evaluate(''.join(board), CPU_FIRST)
		play(screen.slots[cpu_des].xcor(), screen.slots[cpu_des].ycor(), int(not(PLAYER)), cpu_des, not(PLAYER_SYMBOL), loader.SETTINGS['CPU_CLR'])
	elif(int(loader.SETTINGS['CPU_VS_CPU'])):
		cpu_des = cpu.evaluate(''.join(board), int(not(CPU_FIRST)), reverse=True)
		play(screen.slots[cpu_des].xcor(), screen.slots[cpu_des].ycor(), PLAYER, cpu_des, PLAYER_SYMBOL, clr=loader.SETTINGS['PLAYER_CLR'])
	return

def play(xpos, ypos, state, pos, symbol, clr="#00f"):
	global role, board, PLAYER
	if(state == role and board[pos] == '.') :
		screen.drawPos(xpos, ypos, symbol, color=clr)
		board[pos] = str(state)
		role = int(not(role))
		if(gameState(board, PLAYER) == 1) : 
			messagebox.showinfo("game", "you won !? impossible???")
			reset()
			return
		elif(gameState(board, int(not(PLAYER)))):
			messagebox.showinfo("game", "cpu wins [expected :)]")
			reset()
		elif('.' not in board):
			if(int(loader.SETTINGS['LOG_DRAW'])) : messagebox.showinfo("game", "draw")
			reset()
		chk_cpu()
	return


def gameState(board, state):
	cases = lambda s : [str(s) + str(s) + str(s) + '.' + '.' + '.' + '.' + '.' + '.',
			 '.' + '.' + '.' + str(s) + str(s) + str(s) + '.' + '.' + '.',
			 '.' + '.' + '.' + '.' + '.' + '.' + str(s) + str(s) + str(s),
			 str(s) + '.' + '.' + str(s) + '.' + '.' + str(s) + '.' + '.',
			 '.' + str(s) + '.' + '.' + str(s) + '.' + '.' + str(s) + '.',
			 '.' + '.' + str(s) + '.' + '.' + str(s) + '.' + '.' + str(s),
			 str(s) + '.' + '.' + '.' + str(s) + '.' + '.' + '.' + str(s),
			 '.' + '.' + str(s) + '.' + str(s) + '.' + str(s) + '.' + '.']
	if(True in [bool(match(i, ''.join(board))) for i in cases(state)]):
		return 1
	elif(True in [bool(match(i, ''.join(board))) for i in cases(int(not(state)))]):
		return -1
	else:
		return 0

reset()
