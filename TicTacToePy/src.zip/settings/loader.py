SETTINGS = {}
# loading configuration
confFile = open("config.conf", "r")
confData = confFile.readlines()
for i in range(len(confData)):
	tmp = confData[i].split()
	SETTINGS[tmp[0]] = tmp[1]
confFile.close()