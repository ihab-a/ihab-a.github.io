import turtle
from time import sleep
from math import sqrt
from game import game
from settings import loader

WIN_HEIGHT = 600
WIN_WIDTH = 600
screen = turtle.Screen()
screen.bgcolor(loader.SETTINGS['SC_BG_CLR'])
screen.title('XTri V0')
screen.setup(WIN_HEIGHT, WIN_WIDTH)

def createSlots():
	global slots, screen, SETTING
	screen.tracer(0)
	slots = [turtle.Turtle() for _ in range(9)]

	for i in slots:
		i.up()
		i.shape('square')
		i.shapesize(WIN_HEIGHT/60, WIN_WIDTH/60)
		i.color(loader.SETTINGS['SLOT_BORDER_CLR'])
		i.fillcolor(loader.SETTINGS['BG_CLR'])
		i.speed(float(loader.SETTINGS['DRAW_SPD']))
	int(loader.SETTINGS['SLOTS_ANIM']) and screen.tracer(1, 1)

	slots[0].goto(-WIN_HEIGHT/3, WIN_WIDTH/3)
	slots[3].goto(-WIN_HEIGHT/3, 0)
	slots[6].goto(-WIN_HEIGHT/3, -WIN_WIDTH/3)
	slots[1].goto(0, WIN_WIDTH/3)
	slots[4].goto(0, 0)
	slots[7].goto(0, -WIN_WIDTH/3)
	slots[2].goto(WIN_HEIGHT/3, WIN_WIDTH/3)
	slots[5].goto(WIN_HEIGHT/3, 0)
	slots[8].goto(WIN_HEIGHT/3, -WIN_WIDTH/3)
	int(loader.SETTINGS['SLOTS_ANIM']) or screen.update()
	screen.tracer(1, 1)

	slots[0].onclick(lambda x, y : int(loader.SETTINGS['CPU_VS_CPU']) or game.play(slots[0].xcor(), slots[0].ycor(), game.PLAYER, 0, game.PLAYER_SYMBOL, loader.SETTINGS['PLAYER_CLR']))
	slots[1].onclick(lambda x, y : int(loader.SETTINGS['CPU_VS_CPU']) or game.play(slots[1].xcor(), slots[1].ycor(), game.PLAYER, 1, game.PLAYER_SYMBOL, loader.SETTINGS['PLAYER_CLR']))
	slots[2].onclick(lambda x, y : int(loader.SETTINGS['CPU_VS_CPU']) or game.play(slots[2].xcor(), slots[2].ycor(), game.PLAYER, 2, game.PLAYER_SYMBOL, loader.SETTINGS['PLAYER_CLR']))
	slots[3].onclick(lambda x, y : int(loader.SETTINGS['CPU_VS_CPU']) or game.play(slots[3].xcor(), slots[3].ycor(), game.PLAYER, 3, game.PLAYER_SYMBOL, loader.SETTINGS['PLAYER_CLR']))
	slots[4].onclick(lambda x, y : int(loader.SETTINGS['CPU_VS_CPU']) or game.play(slots[4].xcor(), slots[4].ycor(), game.PLAYER, 4, game.PLAYER_SYMBOL, loader.SETTINGS['PLAYER_CLR']))
	slots[5].onclick(lambda x, y : int(loader.SETTINGS['CPU_VS_CPU']) or game.play(slots[5].xcor(), slots[5].ycor(), game.PLAYER, 5, game.PLAYER_SYMBOL, loader.SETTINGS['PLAYER_CLR']))
	slots[6].onclick(lambda x, y : int(loader.SETTINGS['CPU_VS_CPU']) or game.play(slots[6].xcor(), slots[6].ycor(), game.PLAYER, 6, game.PLAYER_SYMBOL, loader.SETTINGS['PLAYER_CLR']))
	slots[7].onclick(lambda x, y : int(loader.SETTINGS['CPU_VS_CPU']) or game.play(slots[7].xcor(), slots[7].ycor(), game.PLAYER, 7, game.PLAYER_SYMBOL, loader.SETTINGS['PLAYER_CLR']))
	slots[8].onclick(lambda x, y : int(loader.SETTINGS['CPU_VS_CPU']) or game.play(slots[8].xcor(), slots[8].ycor(), game.PLAYER, 8, game.PLAYER_SYMBOL, loader.SETTINGS['PLAYER_CLR']))

def _input(title, dialog):
	return turtle.textinput(title, dialog)
def triCenter(A, B, C):
	X = lambda x : x[0]
	Y = lambda x : x[1]
	tmpX = (X(A) + X(B) + X(C)) / 3
	tmpY = (Y(A) + Y(B) + Y(C)) / 3
	return [tmpX, tmpY]

def drawPos(xpos, ypos, state, size=100, color='#5c1dde'):
	tmp = turtle.Turtle()
	tmp.speed(10)
	tmp.color(color)
	tmp.hideturtle()
	if(state):
		tmp.up()
		tmp.goto(xpos + size/2, ypos - size/2)
		tmp.down()
		tmp.goto(tmp.xcor() - size, tmp.ycor() + size)
		tmp.up()
		tmp.goto(xpos + size/2, ypos + size/2)
		tmp.down()
		tmp.goto(tmp.xcor() - size, tmp.ycor() - size)
	else:
		tmp.up()
		tmp.goto(xpos, ypos)
		coordinates = [(tmp.xcor(), tmp.ycor()), (tmp.xcor() + size, tmp.ycor()), (tmp.xcor() + size/2, tmp.ycor() + sqrt(3 * (size**2)/4))]
		offset = triCenter(*coordinates)
		offset = [offset[0] - tmp.xcor(), offset[1] - tmp.ycor()]
		tmp.goto(tmp.xcor() - offset[0], tmp.ycor() - offset[1])
		tmp.down()
		for i in range(3):
			tmp.forward(size)
			tmp.left(120)